# Whatsapp-Brainly-Bot👩‍💻📚
## Bot whatsapp untuk mendapatkan jawaban dari brainly

![](https://img.shields.io/github/issues/diosamuel/Virdina-Brainly)
![](https://img.shields.io/github/stars/diosamuel/Virdina-Brainly)
![](https://img.shields.io/github/forks/diosamuel/Virdina-Brainly)

## Installation 
`git clone https://github.com/diosamuel/Virdina-Brainly.git`

`npm install`

`npm install whatsapp-web.js`

`node index`

and then qrcode will appear on your terminal, scan it!

# Menu

`/help`

![](./menu.jpeg)

# Feature

1. Brainly
  
  * `/brainly <question> -<amount>`
  * example
  * `/brainly pidato bahasa inggris simpel -10`

![](./feature1.jpeg)

2. Image downloader
  
  * `/img <link>`
  * example
  * `/img https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png`

![](./feature2.jpeg)

----
  
**Made with ❤️ by Virdio Samuel**
